Fresh start
